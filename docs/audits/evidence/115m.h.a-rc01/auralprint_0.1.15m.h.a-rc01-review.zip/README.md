# RC-01 review package — v0.1.15m.h.a

Preset schema remains 10. 115N promotion is withheld; Build 115 is not canonical.

- source/: complete current source, tests, scripts, and lockfile; dependencies and build intermediates are excluded.
- dist/auralprint_0.1.15m.h.a.html: validated single-file build.
- rc01-report.md: closure report and scope/complexity reasoning.
- rc01-m-h-a.patch: the nine-file implementation patch against M.H main 0cd79958d3f0156d52c4f68e36458298d6accd9b.
- validation/: baseline/final/package checks, mutation failure evidence, and unchanged historical reproduction.
- manifest.json: SHA-256 for every other archive member.

To rebuild, enter source/ and run npm ci, npm test, then npm run build sequentially.
To rerun the historical worker after extracting, run from source/: timeout 2s node ../validation/id-worker.mjs control (or huge-add / huge-import).
Mutation logs intentionally show failures; the correct implementation is present in source/ and passes the final/package tests.
The historical program is unchanged. The historical M.H defect outputs remain in audit PR #26; current observations assert the corrected M.H.A behavior.
