# Revision 115M.H.A — RC-01 closure report

RC-01 is corrected in the tested M.H.A workspace and ready for developer acceptance. 115N remains WITHHELD. Build 115 is not canonical. Audit remediation remains active; work stops here before RC-02.

| Requested item | Result |
| --- | --- |
| Baseline | Verified GitHub main `0cd79958d3f0156d52c4f68e36458298d6accd9b`, `v0.1.15m.h`, schema 10. Clean install, all 18 test files, build, and `git diff --check` passed before edits. |
| Target Defect | RC-01 only, P1 / CRITICAL: unsafe numeric Orb IDs can hang allocation/import. |
| Audit Finding | PR #26, `docs/audits/2026-10-06_214431_PDT-release-audit.md`, read at its pinned head `3685b4306a367c54879217caf7f709c2a6a91237`. PR #26 is open; its evidence is not on main. |
| Root Cause | Decimal suffixes became JavaScript Numbers; `maxSuffix + 1` and `suffix++` could stop advancing while the used-ID condition stayed true. |
| Confirmed Unsafe Numeric Behavior | `Number("9007199254740992")` is unsafe; adding 1 and incrementing both leave it unchanged. Independently confirmed under external two-second subprocess timeouts: huge Add and duplicate-ID URL import stalled; ORB42 control completed. |
| Identity Contract | Persistent Orb identities remain non-empty trimmed opaque strings. Validation, collection ordering, and preset normalization ownership are unchanged. |
| Arbitrary String IDs Preserved | Yes: HISTORICAL-Z, spectral-ring, CUSTOM-7, Unicode IDs, and nonnumeric ORB-like identities remain accepted and unchanged. |
| Generated-ID Strategy | Parse only `/^ORB(\d+)$/` suffixes with BigInt, take the exact maximum, and return its successor as a canonical ORB string. BigInt is local to allocation; no persisted field contains BigInt. |
| Termination Argument | One finite input scan and one exact increment; no retry loop. Every matching used suffix is at most the maximum, so its successor cannot be any used canonical ORB identity. Nonmatching opaque strings cannot equal the generated canonical ID. |
| Complexity | O(n) ID visits per allocation, with parsing/comparison costs dependent on suffix text/bit length. No iteration depends on numeric magnitude. Only the current maximum is retained. Existing collection repair may call allocation repeatedly and retains its existing worst-case quadratic number of ID visits; that ownership/performance architecture was not changed. |
| Huge-ID Import | Supported schema-10 single/duplicate payloads decode, sanitize, and apply successfully. |
| Huge-ID Add | Direct collection and real runtime Add after URL import terminate with a unique string ID. Single huge ID produces ORB9007199254740993. |
| Huge-ID Duplicate | Direct collection and real runtime Duplicate after import terminate with a unique string ID and preserve the source configuration/runtime identity. |
| Duplicate Huge-ID Repair | `[ORB9007199254740992, ORB9007199254740992]` becomes `[ORB9007199254740992, ORB9007199254740993]`, deterministically, without changing order. |
| Ordinary Allocation | Empty → ORB0; ORB0/ORB1 → ORB2; ORB0/ORB42 → ORB43. Leading-zero imported identities remain unchanged while generated IDs stay canonical. |
| Opaque-ID Behavior | HISTORICAL-Z and spectral-ring survive collection normalization and real URL roundtrips unchanged. Add and Duplicate remain valid. Zero Orbs stays valid. |
| URL Integration | Raw unpadded base64url UTF-8 JSON → real decode/sanitize/apply → preferences → runtime Add/Duplicate → share/re-import passes for both single and duplicate huge IDs. URL format and persisted fields are unchanged. |
| Schema | 10, unchanged in source, unit assertions, re-encoded payloads, and built HTML. |
| Version | `v0.1.15m.h.a`. Existing version reader preserves dotted strings unambiguously; no build-tool change was needed. Source metadata and current-version assertion are aligned. |
| Regression Tests Added | Ordinary/sparse/leading-zero allocation, opaque strings, later explicit identity reservation in the collection owner, safe-integer boundaries, exact 40-/400-digit suffixes, duplicate huge-ID repair, decode/sanitize/encode string persistence, later model Add/Duplicate, and real URL/runtime integration. |
| Timeout-Protected Test | Isolated Node worker with a 3000 ms parent timer and `worker.terminate()` in `finally`; it exercises allocation, sanitation, URL import, Add, and Duplicate before the direct huge-ID unit tests. Failure prevents entry into direct synchronous cases. |
| Mutation Check | Temporarily restored the exact M.H Number/+1/suffix++ allocator. Focused test failed after 3.096 s with `Huge-ID worker timed out after 3000 ms (before allocation)`; full `npm test` failed and exited after 5.111 s (18 passing files, one failing file). The correct source was restored in `finally` and then revalidated. |
| Historical Audit Repro After Fix | The unchanged id-worker.mjs exits 0 within the external two-second limit in control, huge-add, and huge-import modes. Huge Add now prints ORB9007199254740993. The old timeout expectation is invalidated. The script itself does not assert a hang; its successful exit now establishes completion, while the historical recorded outputs still document the M.H defect. |
| Full Tests | PASS: `npm test`, all 19 test files, zero failures. Direct focused runs also pass: termination 12 reported tests, collection 9, schema 64, URL band integration 2. |
| Build | PASS: `npm run build`, sequentially after full tests. Existing ES2020 target supports BigInt; single-file packaging remains intact. |
| Artifact | `dist/auralprint_0.1.15m.h.a.html`, 369,256 bytes. SHA-256: `88292a9098e4afe57d07e4995f87aaa6b9154343041e3768fbd0877f20772b6a`. |
| git diff --check | PASS, including final documentation status edits. |
| Files Changed | Nine implementation/test/metadata/status files, plus this report, a review archive, and its manifest. |
| Unrelated Audit Findings Touched | None. No audio, rendering, simulation, recorder, queue, scrubber, workspace UI, CSS, or template implementation changes. No resource limits/caps/budgets. |
| Conflicts / Deviations | No implementation scope deviations or stop-condition coupling. The first npm invocation needed a writable workspace cache. Worker-based protection was used because child-process APIs behaved inconsistently in this sandbox; workers are an allowed test mechanism. |
| RC-01 Status | CLOSED in the tested M.H.A implementation; ready for developer acceptance. |
| 115N Promotion Status | WITHHELD. Build 115 remains noncanonical; the remaining audit findings are unresolved. |

The explicit-identity reservation regression targets `normalizeOrbCollection()`'s existing contract. The separate RC-09 missing-ID/positional-fallback defect in the preset codec remains unchanged. RC-01 required no edit to `preset-codec.js`, `preferences.js`, `config.js`, or URL transport. RC-22's confirmation-label issue also remains unchanged; spectral-ring is still an accepted Orb identity.

Historical evidence was read from the immutable audit commit and extracted byte-for-byte to scratch for execution. Its worker blob remains `96e63b0dba508d24d6372b4e944f64aa43271b89`. No historical audit report or historical evidence file was changed. The corrective branch adds this separate closure report and the requested review package. The new regression asserts intended M.H.A behavior separately.

Changed files:

- `src/js/core/orb-collection.js` — exact allocator and removal of the unsafe retry loop.
- `tests/orb-id-termination.test.js` — timeout worker, direct numeric/import tests, and URL/runtime integration.
- `tests/orb-collection.test.js` — ordinary and opaque identity contract checks.
- `tests/preset-schema-10.test.js` — opaque-ID URL preservation.
- `version` — target revision.
- `src/js/core/constants.js` — source version comment only; schema constant unchanged.
- `tests/targeted-audit.test.js` — exact current-version assertion.
- `README.md` — current revision/artifact and withheld promotion status.
- `ROADMAP.md` — current revision/date and active audit-remediation status.

Review branch: `codex/115m-h-a-rc01`, targeting the verified M.H `main` baseline. The bundled implementation patch covers the nine implementation/test/metadata/status files and was checked against the workspace using `git apply --reverse --check`. No merge, deployment, canonical release, or work on RC-02 is part of this PR.

The [review package](evidence/115m.h.a-rc01/auralprint_0.1.15m.h.a-rc01-review.zip) contains the complete current build source, single-file HTML, implementation patch, this report, and validation evidence: baseline/final command logs, focused logs, numeric/hang observations, mutation failure logs, historical-after-fix observations, and final hashes. The [manifest](evidence/115m.h.a-rc01/manifest.json) records archive/member SHA-256 hashes. It contains no altered historical audit outputs. No fresh cross-browser or real-media acceptance is claimed; this pass verifies the allocator, supported transport, collection runtime boundary, existing test suite, and build required for RC-01.

The packaged source snapshot was separately installed from the unchanged lockfile with a writable workspace cache, then tested and built sequentially. All 19 test files passed, and its generated HTML is byte-identical to the validated artifact above. Package verification logs are included. Generated dependencies and intermediate build directories are excluded; the source can be rebuilt using `npm ci`, `npm test`, then `npm run build`.
